g.wavread = function(binfile,start=1,end=100,units="minutes") {
  return(NULL) 
}